# SAMPLE SOLUTION FOR TEACHERS LEARNING CODE REPORT CARD ACTIVITY
classAvg = 0
subject = "Computer Science"
honourRoll = []
fail = []


class Student:
    def __init__(self, fn, ln, t1, p1):
        self.firstName = fn
        self.lastName = ln
        self.test1 = t1
        self.project1 = p1

        self.finalGrade = (self.test1 + self.project1)/2
        if self.finalGrade < .5:
            self.coursePass = False
        else:
            self.coursePass = True

def formatStudent(student):
    print("First name: " + student.firstName)
    print("Last name: " + student.lastName)
    print("Test grade: " + str(student.test1))
    print("Project grade: " + str(student.project1))
    print("Final grade: " + str(student.finalGrade))

    if student.coursePass == False:
        print("Pass: no")
    else:
        print("Pass: yes")


student1 = Student("Raghav", "Sampangi", .8, .95)
student2 = Student("Mel", "Sariffodeen", .95, 1.0)
student3 = Student("Ariane", "Hanlon", .4, .3)

studentList = [student1, student2, student3]

import sys

for item in studentList:
    classAvg = classAvg + item.finalGrade

    if item.finalGrade >= .8:
        honourRoll.append(item.lastName)
    if item.finalGrade < .5:
        fail.append(item.lastName)

    sys.stdout = open(item.lastName + ".txt", "w+")
    formatStudent(item)

classAvg = classAvg/len(studentList)

report = open("classReport.txt", "w+")
report.write("Class subject: " + subject + "\n")
report.write("Class average: " + str(classAvg) + "\n")
report.write("Honour roll: " + str(honourRoll) + "\n")
report.write("Students who failed: " + str(fail))
